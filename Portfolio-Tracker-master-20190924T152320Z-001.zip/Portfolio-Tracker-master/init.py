import data
print(port_data.portfolio_daily_data())